package invaders.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Iterator;




import invaders.GameObject;
import invaders.Builder.BunkerBuilder;
import invaders.Builder.EnemyBuilder;
import invaders.BunkerState.GreenBunkerState;
import invaders.Projectiles.EnemyProjectile;
import invaders.Projectiles.Projectile;
import invaders.Projectiles.ProjectileFactory;
import invaders.Projectiles.ProjectileMovement;
import invaders.entities.Enemy;
import invaders.entities.Bunker;
import invaders.entities.Player;
import invaders.logic.EnemyPattern;

import invaders.physics.Vector2D;
import invaders.rendering.Renderable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


/**
 * This class manages the main loop and logic of the game
 */
public class GameEngine {


	public static int gameWidth;
	public static int gameHeight;

	private List<GameObject> gameobjects;
	private List<Renderable> renderables;
	private EnemyPattern enemyPattern;
	private List<Projectile> projectiles = new ArrayList<>();
	private List<Enemy> enemies = new ArrayList<>();
	private List<Bunker> bunkers = new ArrayList<>();
	private List<Projectile> enemyProjectiles = new ArrayList<>();
	private Random random = new Random();

	private Projectile playerProjectile = null;


	private Player player;
	private Enemy enemy;
	private Bunker bunker;

	private double increase = 0.01; 
	

	private boolean left;
	private boolean right;

	public GameEngine(String config){
		
		gameobjects = new ArrayList<GameObject>();
		renderables = new ArrayList<Renderable>();
		enemies = new ArrayList<>();
		bunkers = new ArrayList<>();

		JSONParser parser = new JSONParser();
		
		// read the config here with erroe handling
		try {
            Object object = parser.parse(new FileReader("src/main/resources/config.json"));
            JSONObject jsonObject = (JSONObject) object;

			JSONObject Game = (JSONObject) jsonObject.get("Game");
			Long Width = (Long) ((JSONObject) Game.get("size")).get("x");
			Long Height = (Long) ((JSONObject) Game.get("size")).get("y");

			gameHeight = Height.intValue();
			gameWidth = Width.intValue();


            // Read the Config file and creates the player object
            JSONObject Player = (JSONObject) jsonObject.get("Player");
			Long x = (Long) ((JSONObject) Player.get("position")).get("x");
			Long y = (Long) ((JSONObject) Player.get("position")).get("y");
			Long playerLives = (Long) Player.get("lives");
			Long playerSpeeds = (Long) Player.get("speed");
			String playerColour = (String) Player.get("colour");
			int playerLive = playerLives.intValue();
			int playerSpeed = playerSpeeds.intValue();

			int playerX = x.intValue();
			int playerY = y.intValue();
			player = new Player(new Vector2D(playerX, playerY),projectiles, playerLive, playerColour, playerSpeed);
			renderables.add(player);


            // Read the Config file and creates the enemy object
            JSONArray Enemies = (JSONArray) jsonObject.get("Enemies");
            for (Object obj : Enemies) {
                JSONObject jsEnemy = (JSONObject) obj;
                Long enemyX = (Long) ((JSONObject) jsEnemy.get("position")).get("x");
                Long enemyY = (Long) ((JSONObject) jsEnemy.get("position")).get("y");
                String projectileStrategy = (String) jsEnemy.get("projectile");
				ProjectileMovement projectileType = ProjectileFactory.createNewEnmyStrategy(projectileStrategy);

                enemy = new EnemyBuilder.Builder()
                        .position(new Vector2D(enemyX, enemyY))
						.health(100)
						.image(new File("src/main/resources/enemy.png"))
						.width(35)   
						.height(35)  
						.setProjectileStrategy(projectileType)
						.Collider(25, 25, new Vector2D(enemyX, enemyY))
					 	.build();


                renderables.add(enemy);
				gameobjects.add(enemy);
				enemies.add(enemy);
				enemyPattern = new EnemyPattern(enemies);
				
            }
				
            // Read the JSON config file from and creates Bunkers
            JSONArray jsonBunkers = (JSONArray) jsonObject.get("Bunkers");
            for (Object obj : jsonBunkers) {
                JSONObject jsonBunker = (JSONObject) obj;
                Long bunkerX = (Long) ((JSONObject) jsonBunker.get("position")).get("x");
                Long bunkerY = (Long) ((JSONObject) jsonBunker.get("position")).get("y");
				Long sizeWidth = (Long) ((JSONObject) jsonBunker.get("size")).get("x");
				Long sizeheight = (Long) ((JSONObject) jsonBunker.get("size")).get("y");


                bunker = new BunkerBuilder.Builder()
                        .position(new Vector2D(bunkerX, bunkerY))
						.health(100)
						.image(new File("src/main/resources/green_0.png"))
						.width(sizeWidth)
						.height(sizeheight)
						.Collider(25, 25, new Vector2D(bunkerX, bunkerY))
						.setInitialState(new GreenBunkerState())
                        .build();


                renderables.add(bunker);
				bunkers.add(bunker);
            }

        } catch (IOException | ParseException e) {
            e.printStackTrace();

			System.out.println("There was an error with loading the JSON file");
        }
    }





	
	/**
	 * Updates the game/simulation
	 */
	public void update(){
		

		movePlayer(); // moves the player based on the keyboard input
	
		for(GameObject go: gameobjects){
			go.update(); // updates the game objects with their update implementation
			enemyPattern.update(enemies, increase); // updates the enemy movment pattern after creating an object of the enemies 
		}
		

		for (Projectile projectile : projectiles) {
			projectile.move(); // makes the Player Projectile move in a stright down called from the projectile of the player
		}


		for (Projectile projectile : enemyProjectiles) {
			projectile.move(); // makes the Enemy Projectile move in their respective types called from the projectile of the Enemy. 
		}

	

		if (playerProjectile != null) { // To maintain the single projectile of the Player
			playerProjectile.move();
			if (isPlayerProjectileOutOfBoundary(playerProjectile)) {
			playerProjectile = null;
			} 
		}


		// Check for collisions between enemy projectiles and player projectiles
		for (Projectile enemyProjectile : enemyProjectiles) {
			for (Projectile playerProjectiles : projectiles) {
				if (enemyProjectile.getCollider().isColliding(playerProjectiles.getCollider())) {
					enemyProjectile.markForDeletetion();
					playerProjectiles.markForDeletetion();
					playerProjectile = null;
				}
			}
		}

		creatorEnemyProjectiles();
		handlerBunkerCollisions();


		// Iterate through enemy projectiles to check if collided with player or off screen
		Iterator<Projectile> enemyProjectileIterator = enemyProjectiles.iterator();
		while (enemyProjectileIterator.hasNext()) {
			Projectile projectile = enemyProjectileIterator.next();
			
			// Check if an enemy projectile collides with the player
			if (projectile.getCollider().isColliding(player.getCollider())) {
				player.updatelives(); // Update player lives 
				projectile.markForDeletetion(); // Mark the enemy projectile for deletion
				enemyProjectileIterator.remove();
				if(player.getlives() == 0) {
					endGame();
				}
				break; 

			}
			
			// Check if an enemy projectile is out of the game window
			if (isEnemyProjectileOutOfBoundary(projectile)) {
				projectile.markForDeletetion();
				enemyProjectileIterator.remove();
			}

			

		}

		enemyProjectiles.removeIf(Projectile::isMarkedForDeletion);

		// Iterate through enemies and player projectiles colliding 
		Iterator<Enemy> enemyIterator = enemies.iterator();
			while (enemyIterator.hasNext()) {
				Enemy enemy = enemyIterator.next();
				for (Projectile projectile : projectiles) {
					if (projectile.getCollider().isColliding(enemy.getCollider())) {
						projectile.markForDeletetion();
						enemyIterator.remove(); // Remove the enemy
						enemy.markForDeletion();
						playerProjectile = null;
						increase += 0.005;
						break; 
					}
				}

				if (player.getCollider().isColliding(enemy.getCollider())) {
					endGame();
				}
			}
		
		// Iterate through player projectiles	
		Iterator<Projectile> projectileIterator = projectiles.iterator();
		while (projectileIterator.hasNext()) {
			Projectile projectile = projectileIterator.next();

			// Handle Player projectiles colliding with bunkers
			for (Bunker bunker : bunkers) {
				if (projectile.getCollider().isColliding(bunker.getCollider())) {
					bunker.takeProjectileHits();
					projectile.markForDeletetion();
					playerProjectile = null;
					break;
				}
			}		

			// Check if the Player projectile has reached the end of the Game Window
			if (isPlayerProjectileOutOfBoundary(projectile)) {
				projectile.markForDeletetion();
				
			}

		}


		projectiles.removeIf(Projectile::isMarkedForDeletion);
		bunkers.removeIf(Bunker:: isMarkedForDeletion);
	

		
		// ensure that renderable foreground objects don't go off-screen
		for(Renderable ro: renderables){
			if(!ro.getLayer().equals(Renderable.Layer.FOREGROUND)){
				continue;
			}
			if(ro.getPosition().getX() + ro.getWidth() >= gameWidth) {
				ro.getPosition().setX(639-ro.getWidth());
			}

			if(ro.getPosition().getX() <= 0) {
				ro.getPosition().setX(1);
			}

			if(ro.getPosition().getY() + ro.getHeight() >= gameHeight) {
				ro.getPosition().setY(399-ro.getHeight());
			}

			if(ro.getPosition().getY() <= 0) {
				ro.getPosition().setY(1);
			}
		}
	}

	public List<Renderable> getRenderables(){
		return renderables;
	}
	

	public List<GameObject> getGameObjects(){
		return gameobjects;
	}

	public void leftReleased() {
		this.left = false;
	}

	public void rightReleased(){
		this.right = false;
	}

	public void leftPressed() {
		this.left = true;
	}
	public void rightPressed(){
		this.right = true;
	}



	public boolean shootPressed() {
		 if (playerProjectile == null && projectiles.size() < 1) {
			double x = player.getPosition().getX() ;
			double y = player.getPosition().getY();
			Vector2D projectileStartPos = new Vector2D(x, y);
			playerProjectile = ProjectileFactory.createPlayerProjectile(projectileStartPos);
			projectiles.add(playerProjectile);
			renderables.add((Renderable) playerProjectile);
			return true;
		}
		return false; 
	}

	private void movePlayer(){
		if(left){
			player.left();
		}

		if(right){
			player.right();
		}
	}

	private boolean isPlayerProjectileOutOfBoundary(Projectile projectile) {
		if (projectile.getPosition().getY() < 2) {
			playerProjectile = null;
			return true;
		}
		return false;
	}

	private boolean isEnemyProjectileOutOfBoundary(Projectile projectile) {
		return projectile.getPosition().getY() >= gameHeight - 50;
	}
	
	/**
	 * Handles the Random Creation of enemy projectiles
	 */

	private void creatorEnemyProjectiles() {
		// makes sure that there there are only three enemy projectiles in the game at any given time
		if (enemyProjectiles.size() < 3) {
			// Randomly choose an enemy to shoot
			if (random.nextInt(100) < 5) { 
				int randomEnemyNo = random.nextInt(enemies.size());
				Enemy randomEnemy = enemies.get(randomEnemyNo);
	
				
				ProjectileMovement strategy = randomEnemy.getProjectileType();
	
				// Create an enemy projectile with the enemy's strategy
				Vector2D enemyProjectilePosition = new Vector2D(randomEnemy.getPosition().getX(), randomEnemy.getPosition().getY());
  				Projectile enemyProjectile = new EnemyProjectile(enemyProjectilePosition, strategy);
	
				
				enemyProjectiles.add(enemyProjectile);
				renderables.add((Renderable) enemyProjectile); // Add the projectile as a renderable

				
			}
		}
		
	}
	
	/**	
	 * Handles the bunker collisons of enemy projectile with the bunker changing their bunker state
	 */

	private void handlerBunkerCollisions() {
		// Check the projectile list to see if the enemy projectile has collided with the bunker. 
		for (Projectile enemyProjectile : enemyProjectiles) {
			for (Bunker bunker : bunkers) {
				if (enemyProjectile.getCollider().isColliding(bunker.getCollider())) {
					bunker.takeProjectileHits();
					enemyProjectile.markForDeletetion(); // Mark the enemy projectile for deletion
					break; 
				}
			}

		}
	
	}

	/**	
	 * close game window
	 */

	public void endGame() {
		System.exit(0);
	}

}

