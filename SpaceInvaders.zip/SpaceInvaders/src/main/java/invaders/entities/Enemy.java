package invaders.entities;
import invaders.GameObject;
import invaders.Projectiles.ProjectileMovement;
import invaders.physics.BoxCollider;
import invaders.physics.Moveable;
import invaders.physics.Vector2D;
import invaders.rendering.Renderable;
import javafx.scene.image.Image;




/**
 * Enemy object class.
 * Enemy move in a pattern and can shoot the player
 */
public class Enemy implements Moveable, Renderable, GameObject {
    private final Vector2D position;
    private double health = 100;
    private final Image image;
    private final double width;
    private final double height;
    public BoxCollider collider;
    private boolean markedForDeletion = false;

    private ProjectileMovement projectileType; 


     /**
     * Constructs a Enemy object with attributes passed in from a builder.
     *
     * @param position      The position of the Enemy : Vector2D.
     * @param health        The health of the Enemy not being used.
     * @param image         The image of the Enemy.
     * @param width         The width of the Enemy.
     * @param height        The height of the Enemy.
     * @param collider      The Boxcollider:  the Enemy's collision box.
     * @param projectileType The type of projectile this enemy uses either fast or slow.
     */


    public Enemy(Vector2D position, double health, Image image, ProjectileMovement projectileType, double width, double height, BoxCollider collider) {
        this.position = position;
        this.health = health;
        this.image = image;
        this.width = width;
        this.height = height;
        this.collider =  new BoxCollider(20, 20, position);
        this.projectileType = projectileType;

    }

  
    /**
     * Move the enemy up not needed.
     */
    @Override
    public void up() {
        return;
    }

     /**
     * Move the enemy down not needed.
     */

    @Override
    public void down() {
        return;
    }

    /**
     * Move the enemy left and the box collider.
     */
    @Override
    public void left() {
        this.position.setX(this.position.getX() - 0.01);
        this.collider.setColliderPosition(this.position);
    }


     /**
     * Move the enemy right and the box collider.
     */
    @Override
    public void right() {
        this.position.setX(this.position.getX() + 0.01);
        this.collider.setColliderPosition(this.position);
    }


     /**
     * Getter method for the image of the enemy.
     *
     * @return image of the enemy.
     */


    @Override
    public Image getImage() {
        return this.image;
    }



    /**
     * Getter method for the width of the enemy.
     *
     * @return  width of the enemy.
     */

    @Override
    public double getWidth() {
        return width;
    }

     /**
     * Getter method for the height of the enemy.
     *
     * @return  width of the enemy.
     */

    @Override
    public double getHeight() {
        return height;
    }



    /**
     * Getter method for the positon of the enemy.
     *
     * @return psotion: Vector2D of the enemy.
     */

    @Override
    public Vector2D getPosition() {
        return position;
    }


    /**
     * Getter method for the layer of the enemy for rendering.
     *
     * @return The layer of the enemy as a Renderable.Layer.
     */


    @Override
    public Layer getLayer() {
        return Layer.FOREGROUND;
    }
    


     /**
     * Getter method for the Boxcollider of the enemy.
     *
     * @return The Box collider of the enemy.
     */

    public BoxCollider getCollider() {
        return collider;
    }



    /**
     * Mark the enemy for deletion.
     */

    public void markForDeletion() {
        this.markedForDeletion = true;
    }


    /**
     * Check if the enemy is marked for deletion.
     *
     * @return True if the enemy is marked for deletion, false otherwise.
     */
    
    @Override
    public boolean isMarkedForDeletion() {
        return markedForDeletion;
    

    }

     /**
     * Get the type of projectile this enemy is instantiated with.
     *
     * @return The projectile type fast or slow.
     */
    public ProjectileMovement getProjectileType() {
        return projectileType;
    }

      /**
     * Update method for the enemy.
     * Overriden by the enemy patttern
     */
    @Override
    public void update() {
        
    }

    /**
     * Start method for the enemy.
     * No use
     */

    @Override
    public void start() {
     
    }


}