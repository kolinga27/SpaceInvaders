package invaders.entities;
import invaders.BunkerState.BunkerState;
import invaders.physics.BoxCollider;
import invaders.physics.Vector2D;
import invaders.rendering.Renderable;
import javafx.scene.image.Image;




/**
 * Bunker object class.
 * Bunkers provide a barrier for the player against enemy projectiles.
 */

public class Bunker implements Renderable {
    private final Vector2D position;
    private double health = 3;
    private Image image;
  
    private final double width;
    private final double height;
    private boolean markedForDeletion = false;
    
    private BoxCollider collider;
    private BunkerState bunkerState;
   

    /**
     * Constructs a bunker object with attributes passed in from a builder.
     *
     * @param position      The position of the bunker : Vector2D.
     * @param health        The health of the bunker not being used.
     * @param image         The image of the bunker.
     * @param width         The width of the bunker.
     * @param height        The height of the bunker.
     * @param collider      The Boxcollider:  the bunker's collision box.
     * @param startingState The initial state of the bunker which would be the green bunker state.
     */

    public Bunker(Vector2D position, double health, Image image, double width, double height, BoxCollider collider, BunkerState startingState) {
        this.position = position;
        this.health = health;
        this.image = image;
        this.width = width;
        this.height = height;
        this.collider =  new BoxCollider(30, 30, position);
        this.bunkerState = startingState;
    }


     /**
     * Getter method for the image of the bunker.
     *
     * @return image of the bunker.
     */

    @Override
    public Image getImage() {
        return this.image;
    }

   
    /**
     * Getter method for the width of the bunker.
     *
     * @return  width of the bunker.
     */

    @Override
    public double getWidth() {
        return width;
    }

    /**
     * Getter method for the height of the bunker.
     *
     * @return height of the bunker.
     */

    @Override
    public double getHeight() {
        return height;
    }


    /**
     * Getter method for the positon of the bunker.
     *
     * @return psotion: Vector2D of the bunker.
     */
    @Override
    public Vector2D getPosition() {
        return position;
    }


    /**
     * Getter method for the layer of the bunker for rendering.
     *
     * @return The layer of the bunker as a Renderable.Layer.
     */

    @Override
    public Layer getLayer() {
        return Layer.FOREGROUND;
    }


    /**
     * Handles the bunker being hit by a projectile.
     * This method passes the collison handling to the respective bunker state.
     */

    public void takeProjectileHits() {
        bunkerState.takeProjectileHits(this); 
    }

     /**
     * Change the state of the bunker to a new state.
     * This method updates the bunker's state and image when the state changes.
     *
     * @param changedState changed state of the bunker.
     */

    public void changeState(BunkerState changedState) {
        this.bunkerState = changedState; // Change the state of the Bunker
        this.image = changedState.updateState();// Update the image when state changes
    }
  
     /**
     * Getter method for the Boxcollider of the bunker.
     *
     * @return The Box collider of the bunker.
     */
    public BoxCollider getCollider() {
        return collider;
    }

    /**
     * Mark the bunker for deletion.
     */

    public void markForDeletion() {
        this.markedForDeletion = true;
    }
    

    /**
     * Check if the bunker is marked for deletion.
     *
     * @return True if the bunker is marked for deletion, false otherwise.
     */
    @Override
    public boolean isMarkedForDeletion() {
        return markedForDeletion;
    
    }
}