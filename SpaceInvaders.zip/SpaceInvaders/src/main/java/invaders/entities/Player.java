package invaders.entities;

import invaders.GameObject;
import invaders.Projectiles.Projectile;
import invaders.Projectiles.ProjectileFactory;
import invaders.logic.Damagable;
import invaders.physics.BoxCollider;
import invaders.physics.Moveable;
import invaders.physics.Vector2D;
import invaders.rendering.Animator;
import invaders.rendering.Renderable;

import javafx.scene.image.Image;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Player implements Moveable, Damagable, Renderable, GameObject{

    private final Vector2D position;
    private final Animator anim = null;
    private double health = 100;

    private final double width = 25;
    private final double height = 30;
    private final Image image;

    private boolean markedForDeletion = false;


    public BoxCollider collider;
    private int lives; 
    private int speed; 
    private final String colour; 



    private boolean shooting = false;
    private List<Projectile> projectiles;

    public Player(Vector2D position,List<Projectile> projectiles , int lives, String colour, int speed) {
        this.image = new Image(new File("src/main/resources/player.png").toURI().toString(), width, height, true, true);
        this.position = position;
        this.projectiles = new ArrayList<>();
        this.lives = lives;
        this.colour = colour;
        this.speed = speed;
        this.collider = new BoxCollider(30, 30, this.position);
    }
    

    public void updatelives() {
        this.lives -= 1;
    }

    public int getlives() {
        return this.lives;
    }

    public String getColour() {
        return this.colour;
    }


    @Override
    public void takeDamage(double amount) {
        this.health -= amount;
    }

    @Override
    public double getHealth() {
        return this.health;
    }

    @Override
    public boolean isAlive() {
        return this.health > 0;
    }

    @Override
    public void up() {
        return;
    }

    @Override
    public void down() {
        return;
    }

    @Override
    public void left() {
        this.position.setX(this.position.getX() - this.speed);
        this.collider.setColliderPosition(this.position);
        
    }

    @Override
    public void right() {
        this.position.setX(this.position.getX() + this.speed);
        this.collider.setColliderPosition(this.position);
    }

    public void shoot(){
        double projectileX = this.position.getX() + this.width / 2; // Center the projectile to shoot at the middle of the player 
        double projectileY = this.position.getY();  // Center the projectile to shoot at the middle of the player 
        Vector2D projectileStartPos = new Vector2D(projectileX, projectileY);
        Projectile projectile = ProjectileFactory.createPlayerProjectile(projectileStartPos);
        projectiles.add(projectile);
    }

    @Override
    public Image getImage() {
        return this.image;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public Vector2D getPosition() {
        return position;
    }

    @Override
    public Layer getLayer() {
        return Layer.FOREGROUND;
    }

    @Override
    public void update() {

    }

    public void markForDeletion() {
        this.markedForDeletion = true;
    }
    
    @Override
    public boolean isMarkedForDeletion() {
       
        return markedForDeletion;
    
    }

    public BoxCollider getCollider() {
        return collider;
    }


    @Override
    public void start() {
        
    }
    
   
}
