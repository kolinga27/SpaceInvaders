package invaders.logic;

import java.util.List;

import invaders.engine.GameEngine;
import invaders.entities.Enemy;
import invaders.physics.Vector2D;

/**
 * The movement pattern and behavior of enemies in the spaceInvaders game.
 */
public class EnemyPattern {
  
    private boolean isMovingRight = true; // 
    private List<Enemy> enemies;

    /**
     * Constructs an EnemyPattern with the enimies list that has been passsed in.
     *
     * @param enemies The list of enemies behaviour to be set by this pattern.
     */
    
    public EnemyPattern(List<Enemy> enemies) {
        this.enemies = enemies;
    }

    /**
     * Takes in the list of enemies and updates the target position for the enemy and the box collider positon and increaseing the speed when one enemy is removed
     *
     * @param enemies The list of enemies to update.
     * @param i       The amount of which to increase the speed by after the collison is detected in the Game Engine.
     */
    public void update(List<Enemy> enemies, double i) { 
        boolean atScreenEdge = false; // Flag to indicate weather the enemy has reached the screen edge
        for (Enemy enemy : enemies) {
            if (isMovingRight && (enemy.getPosition().getX() + enemy.getWidth()) >= GameEngine.gameWidth) {
                atScreenEdge = true;
                break;
            } else if (!isMovingRight && enemy.getPosition().getX() <= 0) {
                atScreenEdge = true;
                break;
            }
        }

        if (atScreenEdge) {
            for (Enemy enemy : enemies) {
                double newY = enemy.getPosition().getY() + 10;
                enemy.getPosition().setY(newY);
                enemy.collider.setColliderPosition(new Vector2D(enemy.getPosition().getX(), newY));
                if (newY + enemy.getHeight() >= GameEngine.gameHeight) {
                    System.exit(0);
                }
              
            }
            isMovingRight = !isMovingRight;

            
        } else {
            for (Enemy enemy : enemies) {
                if (isMovingRight) {
                    double newX = enemy.getPosition().getX() + i;
                    enemy.getPosition().setX(newX);
                    enemy.collider.setColliderPosition(enemy.getPosition());
                } else {
                    double newX = enemy.getPosition().getX() - i;
                    enemy.getPosition().setX(newX);
                    enemy.collider.setColliderPosition(enemy.getPosition());
                }
            }
        }
    }

}
