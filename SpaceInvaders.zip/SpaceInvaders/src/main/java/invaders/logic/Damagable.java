package invaders.logic;


/**
 * An interface used to apply damagable methods to the game object.
 */
public interface Damagable {

	/**
     * Take a set of damage.
     *
     * @param amount amount of damage to minus.
     */


	public void takeDamage(double amount);


	 /**
     * Getter method for the health of the object.
     *
     * @return The health as a double.
     */

	public double getHealth();

	 /**
     * Check if the object is alive.
     *
     * @return true if the object is alive, false is dead.
     */
	public boolean isAlive();


}
