package invaders.Builder;

import java.io.File;

import invaders.BunkerState.BunkerState;
import invaders.entities.Bunker;
import invaders.physics.BoxCollider;
import invaders.physics.Vector2D;
import javafx.scene.image.Image;

public class BunkerBuilder {
    

     /**
     * Builder class constructing Bunekr objects.
     */
    public static class Builder {
        private Vector2D position;
        private double health;
        private Image image;
        private double width;
        private double height;
        private BoxCollider collider;
        private BunkerState initialState;



          /**
         * Set the position of the bunker.
         *
         * @param position The position of the bunker as a Vector2D.
         * @return The Builder attribute.
         */

        public Builder position(Vector2D position) {
            this.position = position;
            return this;
        }

         /**
         * Set the health of the bunker.
         *
         * @param health The health of the bunker.
         * @return The Builder attribute.
         */

        public Builder health(double health) {
            this.health = health;
            return this;
        }


         /**
         * Set the image for the bunker.
         *
         * @param file The image file for the bunker.
         * @return The Builder attribute
         */

        public Builder image(File file) {
            this.image = new Image(file.toURI().toString());
            return this;
        }

        

        /**
         * Set the width of the bunker.
         *
         * @param width The width of the bunker.
         * @return The Builder atrribute 
         */
        public Builder width(double width) {
            this.width = width;
            return this;
        }
        


        /**
         * Set the height of the bunker.
         *
         * @param height The height of the bunker.
         * @return The Builder attribute.
         */

        public Builder height(double height) {
            this.height = height;
            return this;
        }


         /**
         * Set the collider for the bunker.
         *
         * @param width    The width of the collider.
         * @param height   The height of the collider.
         * @param position The position of the collider as a Vector2D.
         * @return The Builder attribute.
         */

        public Builder Collider(double width, double height, Vector2D position) {
            this.collider = new BoxCollider(width, height, position);
            return this;
        }

         /**
         * Set the initial state for the bunker which would be the green bunker state.
         *
         * @param initialState The initial state of the bunker.
         * @return The Builder attribute.
         */

        public Builder setInitialState(BunkerState initialState) {
            this.initialState = initialState;
            return this;
        }

         /**
         * Build and return a Bunker object read from the JSON file.
         *
         * @return The constructed Bunker object.
         */

        public Bunker build() {
            return new Bunker(position, health, image,width , height, collider, initialState);
        }
        

    }
    
}
