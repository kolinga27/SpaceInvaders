package invaders.Builder;

import java.io.File;

import invaders.Projectiles.ProjectileMovement;
import invaders.entities.Enemy;
import invaders.physics.BoxCollider;
import invaders.physics.Vector2D;
import javafx.scene.image.Image;

public class EnemyBuilder {
    
    /**
     * Builder class constructing Enemy objects.
     */
    public static class Builder {
        private Vector2D position;
        private double health;
        private Image image;
        private double width;
        private double height;
        private ProjectileMovement projectileType;
        private BoxCollider collider;


          /**
         * Set the position of the enemy.
         *
         * @param position The position of the enemy as a Vector2D.
         * @return The Builder attribute .
         */

        public Builder position(Vector2D position) {
            this.position = position;
            return this;
        }

        /**
         * Set the health of the enemy.
         *
         * @param health The health of the enemy.
         * @return The Builder attribute.
         */

        public Builder health(double health) {
            this.health = health;
            return this;
        }

        /**
         * Set the image for the enemy.
         *
         * @param file The image for the enemy.
         * @return The Builder attribute .
         */
        public Builder image(File file) {
            this.image = new Image(file.toURI().toString());
            return this;
        }



        /**
         * Set the width of the enemy.
         *
         * @param width The width of the enemy.
         * @return The Builder attribute .
         */


        public Builder width(double width) {
            this.width = width;
            return this;
        }


        /**
         * Set the height of the enemy.
         *
         * @param height The height of the enemy.
         * @return The Builder attribute.
         */
        
        public Builder height(double height) {
            this.height = height;
            return this;
        }

        /**
         * Set the projectile strategy for the enemy.
         *
         * @param projectileType The ProjectileStrategy type for the enemy weather it's fast or slow.
         * @return The Builder attribute.
         */
        public Builder setProjectileStrategy(ProjectileMovement projectileType) {
            this.projectileType = projectileType;
            return this;
        }
        

        /**
         * Set the collider for the enemy.
         *
         * @param width    The width of the collider to match with the enemy's width.
         * @param height   The height of the collider to match with the enmey's height.
         * @param position The position of the collider as a Vector2D.
         * @return The Builder attribute.
         */
        public Builder Collider(double width, double height, Vector2D position) {
            this.collider = new BoxCollider(width, height, position);
            return this;
        }


        /**
         * Build and return an Enemy object with the attributes read from the JSON files.
         *
         * @return The constructed Enemy object.
         */
        public Enemy build() {
            return new Enemy(position, health, image, projectileType,width, height, collider);
        }

        
    }


    
}
