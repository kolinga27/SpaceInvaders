package invaders.ProjectileMovement;

import invaders.Projectiles.Projectile;
import invaders.Projectiles.ProjectileMovement;


/**
 * A slow straight projectile movement for enemy projectiles.
 */

public class slowEnemyProjectile implements ProjectileMovement {


    /**
     * Move the projectile according to the slow straight movement.
     *
     * @param projectile The projectile to be moved.
     */
    @Override
    public void move(Projectile projectile) { 
        projectile.getPosition().setY(projectile.getPosition().getY() + 0.5);
    }
    
}
