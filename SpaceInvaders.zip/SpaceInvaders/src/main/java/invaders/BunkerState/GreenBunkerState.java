package invaders.BunkerState;

import java.io.File;

import invaders.entities.Bunker;
import javafx.scene.image.Image;


/**
 * Green state of a bunker.
 * This state is initially set for a bunker.
 */

public class GreenBunkerState implements BunkerState {
    
    /**
     * Update the image of the green state of a bunker.
     *
     * @return Green bunker.
     */
    public Image updateState() {
        return new Image(new File("src/main/resources/green.png").toURI().toString());
    }

    /**
     * When the bunker is hit, the bunker changes to the yellow bunker state.
     *
     * @param bunker The bunker that was collided with the projectile.
     */
    @Override
    public void takeProjectileHits(Bunker bunker) {
        bunker.changeState(new YellowBunkerState());
    }
    
}
