package invaders.BunkerState;

import java.io.File;

import invaders.entities.Bunker;
import javafx.scene.image.Image;

public class YellowBunkerState implements BunkerState {
    

    /**
     * update the image of the yellow state of a bunker.
     *
     * @return Green bunker.
     */
    public Image updateState() {
        return new Image(new File("src/main/resources/yellow_1.png").toURI().toString());
    }


    /**
     * When the bunker is hit, the bunker changes to the red bunker state.
     *
     * @param bunker The bunker that was collided with the projectile.
     */
    @Override
    public void  takeProjectileHits(Bunker bunker) {
        bunker.changeState(new RedBunkerState());
    }

    
}
