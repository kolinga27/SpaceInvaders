package invaders.BunkerState;

import invaders.entities.Bunker;
import javafx.scene.image.Image;


/**
 * The BunkerState interface implments the different states of a Bunker.
 * classes that Implement this interface must override this interface methods
 */

public interface BunkerState {
    Image updateState();
    void takeProjectileHits(Bunker bunker);
}