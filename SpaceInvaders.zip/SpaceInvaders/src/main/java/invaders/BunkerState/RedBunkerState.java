package invaders.BunkerState;

import java.io.File;

import invaders.entities.Bunker;
import javafx.scene.image.Image;

public class RedBunkerState implements BunkerState {
    

      /**
     * update the image of the red state of a bunker.
     *
     * @return Red bunker.
     */
    public Image updateState() {
        return new Image(new File("src/main/resources/red_2.png").toURI().toString());
    }


    /**
     * When the bunker is hit, the bunker is deleted of the screen.
     *
     * @param bunker The bunker that was collided with the projectile.
     */
    public void  takeProjectileHits(Bunker bunker) {
        bunker.markForDeletion();
    }
}