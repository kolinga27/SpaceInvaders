package invaders.Projectiles;
import javafx.scene.image.Image;
import invaders.rendering.Renderable;
import invaders.GameObject;
import invaders.physics.BoxCollider;
import invaders.physics.Collider;
import invaders.physics.Vector2D;
import java.io.File;

/**
 * The enemy projectile of an enemy.
 */

public class EnemyProjectile implements Projectile, Renderable, GameObject {
    
    private Vector2D position;
    private final Image image;
    private int width = 40;
    private int height = 40;
    private boolean markedForDeletion = false;
    private BoxCollider collider;
    private ProjectileMovement projectileStrategy;
    
    
     /**
     * Constructs an enemy projectile at the specified starting position with the given projectile strategy.
     *
     * @param startPosition    The initial position of the enemy projectile which is the positon of the enemy at that given time.
     * @param projectileStrategy The fast or slow strategy.
     */


    public EnemyProjectile(Vector2D startPosition, ProjectileMovement projectileStrategy) {
        this.position = startPosition;
        this.image = new Image(new File("src/main/resources/bullet.png").toURI().toString(), width, height, true, true);
        this.collider = new BoxCollider(this.width, this.height, this.getPosition());
        this.projectileStrategy = projectileStrategy; // Projectile has their own strategy Fast or Slow
        
    }



    /**
     * Get the Boxcollider of the enemy projectile.
     *
     * @return The Box collider of the projectile.
     */
    public Collider getCollider() {
        return collider;
    }

    @Override
    public Image getImage() {
        return this.image;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public Vector2D getPosition() {
        return position;
    }

    @Override
    public Layer getLayer() {
        return Layer.FOREGROUND;
    }

    @Override
    public void start() {
        
    }

    @Override
    public void move() {
        projectileStrategy.move(this); 
        this.collider.setColliderPosition(this.position);
    }

    @Override
    public void update() {

    }

    @Override
    public void markForDeletetion() {
        this.markedForDeletion = true;
    }

    @Override
    public boolean isMarkedForDeletion() {
        return markedForDeletion;
    
    }
 
    
}
