package invaders.Projectiles;

import invaders.physics.Collider;
import invaders.physics.Vector2D;

public interface Projectile  {
    /**
     * Implement how the projectile is supposed to move.
     */
    void move();  


    /**
     * Getter method for the width of the projectile.
     *
     * @return The width of the projectile.
     */
    double getWidth(); 

    /**
     * Getter method for the height of the projectile.
     *
     * @return The height of the projectile.
     */

    double getHeight(); 

    /**
     * Getter method for the position of the projectile.
     *
     * @return The position of the projectile.
     */

    Vector2D getPosition(); 
    
    /**
     * Getter method for the collider of the projectile.
     *
     * @return The Box collider of the projectile.
     */



    Collider getCollider();

    /**
     * Mark the projectile for deletion.
     * Used in collision handling to indicate that the projectile should be removed.
     */


    void markForDeletetion(); 

    /**
     * Check if the projectile is marked for deletion.
     *
     * @return true if the projectile is marked for deletion, otherwise false.
     * Used to remove the projectile from the game wundow's screen.
     */

    boolean isMarkedForDeletion(); 

}
