package invaders.Projectiles;

import invaders.ProjectileMovement.slowEnemyProjectile;
import invaders.ProjectileMovement.FastEnemyProjectile;
import invaders.physics.Vector2D;

/**
 * A factory class for creating player projectile or enemy projectile with their Movement strategies. 
 */

public class ProjectileFactory {

     /**
     * Create a player projectile starting from the players position.
     *
     * @param startPosition The starting position of the player projectile.
     * @return  player projectile.
     */
    public static Projectile createPlayerProjectile(Vector2D startPosition) {
        return new PlayerProjectile(startPosition); // creates a projectile that shoots up
    }

     /**
     * Create a enemy projectile and it's strategy based on the projectile type.
     *
     * @param projectile The type of enemy projectile either fast or slow.
     * @return Either a Fast or a Slow straight projectile.
     */

    public static ProjectileMovement createNewEnmyStrategy(String projectile) {
        switch (projectile) {
            case "fast_straight":
                return new FastEnemyProjectile(); // creates a enemy fast stright projectile
                
            case "slow_straight":
                return new slowEnemyProjectile(); // creates a enemy slow stright projectile
        }
        return null;
    }

}
