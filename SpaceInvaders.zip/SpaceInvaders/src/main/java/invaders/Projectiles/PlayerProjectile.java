package invaders.Projectiles;
import java.io.File;

import invaders.GameObject;
import invaders.physics.BoxCollider;
import invaders.physics.Collider;
import invaders.physics.Vector2D;
import invaders.rendering.Renderable;
import javafx.scene.image.Image;


/**
 * player's projectile in the game that implments the Projectile, renderable and GameObject interfaces.
 */


public class PlayerProjectile implements Projectile, Renderable, GameObject {
    
    private Vector2D position;
    private final Image image;
    private int width = 40;
    private int height = 40;
    private boolean markedForDeletion = false; // Intially the player projectile is not marked for deletion
    private BoxCollider collider;

     /**
     * Constructs a player projectile at positon of the player at the given time.
     *
     * @param startPosition The initial position of the player projectile.
     */

    public PlayerProjectile(Vector2D startPosition) { // constructor
        this.position = startPosition;
        this.image = new Image(new File("src/main/resources/bullet.png").toURI().toString(), width, height, true, true);
        this.collider = new BoxCollider(5, 30, startPosition);
        
    }

    @Override
    public void move() { // how the player projectile should be moved with its Boxcollider
        double newY = this.position.getY() - 1;
        this.position.setY(newY);
        this.collider.setColliderPosition(new Vector2D(this.position.getX(), newY));
    }


     /**
     * Get the Boxcollider of the player projectile.
     *
     * @return The Box collider of the projectile.
     */
    public Collider getCollider() {
        return collider;
    }

    @Override
    public Image getImage() {
        return this.image;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public Vector2D getPosition() {
        return position;
    }

    @Override
    public Layer getLayer() {
        return Layer.FOREGROUND;
    }

    @Override
    public void start() {
    }

    @Override
    public void update() {  //updates the position of the collider and the projectile 
        this.position.setY(this.position.getY() - 1);
        this.collider.setColliderPosition(this.position);
    }    


    @Override
    public void markForDeletetion() {
        this.markedForDeletion = true;
    }

    @Override
    public boolean isMarkedForDeletion() {
        return markedForDeletion;
    
    }
 
    
}