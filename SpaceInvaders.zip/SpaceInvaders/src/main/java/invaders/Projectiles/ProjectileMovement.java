package invaders.Projectiles;


/**
 * An interface for updating projectile movement strategy.
 */
public interface ProjectileMovement {

     /**
     * method that is implmented by the different strategies such as fast straight and slow straight. 
     *
     * @param projectile The projectile to be moved.
     */
    void move(Projectile projectile); 
    
}
