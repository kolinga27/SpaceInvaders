package invaders.physics;


/**
 * The box collider class used for collision detection.
 */
public class BoxCollider implements Collider {

    private double width;
    private double height;
    private Vector2D position;

    public BoxCollider(double width, double height, Vector2D position){
        this.height = height;
        this.width = width;
        this.position = position;
    }

    @Override
    public double getWidth() {
        return this.width;
    }

    @Override
    public double getHeight() {
        return this.height;
    }

    @Override
    public Vector2D getPosition(){
        return this.position;
    }

    /**
     * Set the position of the box collider, useful for setting the new position of the collider
     *
     * @param position The new position of the box collider as a Vector2D.
     */

    public void setColliderPosition(Vector2D position) { 
       this.position = position;
    }

}
