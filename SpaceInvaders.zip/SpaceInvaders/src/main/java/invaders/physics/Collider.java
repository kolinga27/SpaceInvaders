package invaders.physics;

public interface Collider {


    /**
     * Getter method for the width of the collider.
     *
     * @return The width of the collider.
     */
    public double getWidth();

     /**
     * Getter method for the height of the collider.
     *
     * @return The height of the collider.
     */

    public double getHeight();


    /**
     * Getter method for the position of the collider.
     *
     * @return The position of the collider as vector2D .
     */



    public Vector2D getPosition();

    /**
     * Check if this collider is colliding with another collider.
     *
     * @param col The collider to check for collision with.
     * @return  true  if there is a collision, otherwise false.
     */

    public default boolean isColliding(Collider col) {
        double minX1 = this.getPosition().getX();
        double maxX1 = this.getPosition().getX() + this.getWidth();
        double minY1 = this.getPosition().getY();
        double maxY1 = this.getPosition().getY() + this.getHeight();

        double minX2 = col.getPosition().getX();
        double maxX2 = col.getPosition().getX() + col.getWidth();
        double minY2 = col.getPosition().getY();
        double maxY2 = col.getPosition().getY() + col.getHeight();

        if (maxX1 < minX2 || maxX2 < minX1) {
            return false; // No overlap in the x-axis
        }

        if (maxY1 < minY2 || maxY2 < minY1) {
            return false; // No overlap in the y-axis
        }

        return true; // Overlap in both x-axis and y-axis
    }

    
}