Space Invaders Game

Game Features

- Enemy: The game includes enemies that move horizontally and descend when they reach the screen's edge.
- PlayerProjectiles: The player can fire projectiles to destroy enemy spaceships or hit the bunker by mistake. This is controlled by space bar.
- Bunkers: Bunkers provide protection for the player and can be damaged by enemy projectiles or the player projectile.
- Collision Detection: The game features collision detection between player projectiles, enemy projectiles, bunkers, and enemies.


How to play the game?

* Movement: Use the arrow keys to move the player's spaceship left and right.
* Fire: Press the Spacebar to fire a projectile from the player.


How is this codebase structured? 

- invaders.Builder: Contains builder classes for creating bunker and enemy.  * Builder Pattern
- invaders.Projectiles: Includes classes for projectiles and projectile Movement. * Factory method.
- invaders.ProjectileMovement: Implementations of the projectile movement strategies. * Strategy pattern.
- invaders.BunkerState: Contains the differnt implmetation states of the bunker. * State pattern.
- invaders.physics: Contains classes for collision detection, colliders, and vector positions.
- invaders.rendering: Handles rendering and animations of the Objects.
- invaders.logic: Contains enemy pattern movement and interfaces for damagable objects.
- invaders.entities: Contains classes for game entities like player, enemies and bunkers.